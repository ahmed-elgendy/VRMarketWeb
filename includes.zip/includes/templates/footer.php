<body>
	<div class="footer">
	</div>
	<script src="<?php echo $js; ?>jquery-3.2.1.min.js"></script>
	<script src="<?php echo $js; ?>jquery-ui.min.js"></script>
	<script src="<?php echo $js; ?>bootstrap.min.js"></script>
	<script src="<?php echo $js; ?>jquery.selectBoxIt.min.js"></script>
	<script src="<?php echo $js; ?>jquery.flexslider-min.js"></script>
	<script src="<?php echo $js; ?>jquery.fancybox.pack.js"></script>
	<script src="<?php echo $js; ?>popper.min.js"></script>
	<script src="<?php echo $js; ?>login.js"></script>
	<script src="<?php echo $js; ?>plugin1.js"></script>
</body>